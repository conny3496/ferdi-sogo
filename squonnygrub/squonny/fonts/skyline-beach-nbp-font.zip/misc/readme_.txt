SKYLINE BEACH NBP
made by Nate Halley
using Fontstruct
Version 1.1
Date: 9 December 2012

DESCRIPTION
===========
Named after the coolest district in The Urbz for GameCube, Skyline Beach hi-tech slant typeface inspired by Russell Square and FF District

CHANGES IN VERSION 1.1
======================
-Added Cyrillic characters

LICENSE
=======
Skyline Beach is Creative Commons (by-sa) Attribution Share Alike. That means it's free to download and use. You can also upload it to another website but only as long as you give me credit for making it. You can even make changes to it as long as you give me credit for making the first version and license your new version as CC-BY-SA too.
For more information, go to:
http://creativecommons.org/licenses/by-sa/3.0/

A REQUEST FROM NATE547
======================
Once you install this font, find 2 ways to make the world, the country, your home state/province/county, or your hometown better than it is. Even if it's just recycling your newspaper instead of tossing it on the rubbish.

If you're upgrading from a previous version of this font, find 2 ways you contribute to global de-evolution (like letting Big Business or peer pressure influence your choices or believing outlandish gossip about people without verifying it first) and take charge of your own destiny.

Of course, you're not obligated by law to do this.... it's just a request from a Sensible Human who wants our world to change.

Duty now for the future.

Nate547 (Total FontGeek)